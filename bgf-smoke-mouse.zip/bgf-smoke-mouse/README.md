# BGF Smoke Mouse

A Pen created on CodePen.io. Original URL: [https://codepen.io/Kyle-Aucamp-the-sans/pen/MWLJGWq](https://codepen.io/Kyle-Aucamp-the-sans/pen/MWLJGWq).

